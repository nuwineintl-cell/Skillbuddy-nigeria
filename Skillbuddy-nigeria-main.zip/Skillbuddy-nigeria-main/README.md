# Skillbuddy-nigeria
# SkillBuddy Nigeria - Static Web App  This repository contains a static web app for *SkillBuddy Nigeria* — an AI-powered learning UI prototype.  ## Folder structure ``` skillbuddy-ai/ ├── css/ │   └── style.css ├── js/ │   ├── app.js │   └── voice-training.js ├── assets/ │   
